/* WebRTC transport: CloudBase auto-room signaling, with manual SDP fallback. */
import { HVTGame } from './game-engine.js';
import { OnlineSignal } from './online-signal.js';

const RTC_CONFIG = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
  ],
};
const ICE_TIMEOUT_MS = 25000;
const COMMAND_TTL_MS = 15000;
let gameMap = null;
let pc = null;
let channel = null;
let room = '';
let role = '';
let host = false;
let myName = 'Player';
let peerName = '';
let engine = null;
let started = false;
let ready = { attacker: false, defender: false };
let offerText = '';
let answerText = '';
let incomingOffer = '';
let connected = false;
let connectionStatus = 'idle';
let answerApplied = false;
let acceptingAnswer = null;
let callbackSet = null;
let requestSerial = 0;
const pendingRequests = new Map();
let processing = Promise.resolve();
let mode = 'manual';
let roomAuth = null;
let pollTimer = null;
let generation = 0;
let connectionPath = 'unknown';
const AUTO_POLL_MS = 2800;


const cleanName = value => String(value || 'Player').trim().slice(0, 20) || 'Player';
const randomCode = () => Array.from(crypto.getRandomValues(new Uint8Array(4)))
  .map(value => value.toString(16).padStart(2, '0')).join('').toUpperCase();
const parseDescription = (text, expectedType) => {
  let value;
  try { value = JSON.parse(String(text || '').trim()); }
  catch { throw Error('连接文本不是有效的 JSON，请完整复制邀请/答复内容。'); }
  if (!value || value.type !== expectedType || typeof value.sdp !== 'string') {
    throw Error(`连接文本格式错误：需要 ${expectedType} 描述。`);
  }
  return value;
};

function emitOnline(value) {
  const next = !!value;
  if (connected === next) return;
  connected = next;
  callbackSet?.onOnline?.(connected);
}
function emitConnectionStatus(status) {
  if (connectionStatus === status) return;
  connectionStatus = status;
  callbackSet?.onConnectionStatus?.(status);
}
function updateConnectionState(connection = pc) {
  // Ignore late callbacks from a connection that has already been replaced.
  if (!connection || connection !== pc) return;
  const isOpen = channel?.readyState === 'open';
  const isConnected = connection.connectionState === 'connected' && isOpen;
  emitOnline(isConnected);
  if (isConnected && connectionPath === 'unknown') void detectConnectionPath(connection);

  let state;
  if (isConnected) state = 'connected';
  else if (connection.connectionState === 'failed' || connection.iceConnectionState === 'failed') state = 'failed';
  else if (connection.connectionState === 'closed' || connection.iceConnectionState === 'closed' || channel?.readyState === 'closed') state = 'closed';
  else if (connection.connectionState === 'disconnected' || connection.iceConnectionState === 'disconnected') state = 'disconnected';
  else state = host && !answerApplied ? 'waiting-answer' : 'connecting';
  emitConnectionStatus(state);
}
async function detectConnectionPath(connection) {
  try {
    if (!connection?.getStats) return;
    const reports = await connection.getStats();
    if (connection !== pc) return;
    let selected;
    for (const report of reports.values()) {
      if (report.type === 'transport' && report.selectedCandidatePairId) {
        selected = reports.get(report.selectedCandidatePairId);
        break;
      }
    }
    if (!selected) {
      for (const report of reports.values()) {
        if (report.type === 'candidate-pair' && report.state === 'succeeded' && report.nominated) {
          selected = report; break;
        }
      }
    }
    const candidate = selected && reports.get(selected.localCandidateId);
    connectionPath = candidate?.candidateType === 'relay' ? 'turn-relay'
      : candidate ? 'direct' : 'unknown';
    callbackSet?.onConnectionStatus?.(connectionStatus);
  } catch (error) { console.warn('Candidate path inspection failed:', error); }
}
function schedulePoll(sequence) {
  if (sequence !== generation || mode !== 'auto' || !roomAuth) return;
  pollTimer = setTimeout(async () => {
    try {
      const result = await OnlineSignal.call('poll', { code: roomAuth.code, token: roomAuth.token });
      if (sequence !== generation) return;
      if (result.status === 'closed') throw Error('房间已关闭');
      if (host && result.answer && !answerApplied && pc?.signalingState === 'have-local-offer') {
        await acceptAnswer(JSON.stringify(result.answer));
      }
    } catch (error) {
      if (sequence !== generation) return;
      // Network errors are transient: retry; explicit expiry/closure requires a new room.
      if (/关闭|过期|没有找到|无权/.test(String(error?.message))) {
        emitOnline(false); emitConnectionStatus('failed');
        console.warn('Room expired:', error);
        return;
      }
      console.warn('Signaling poll retry:', error);
    }
    schedulePoll(sequence);
  }, AUTO_POLL_MS);
}
function lobbyState() {
  return {
    room: room || 'P2P',
    started,
    ready: !!(ready.attacker && ready.defender),
    players: {
      attacker: { nickname: host ? myName : peerName, ready: !!ready.attacker },
      defender: { nickname: host ? peerName : myName, ready: !!ready.defender },
    },
  };
}
function emitLobby() { callbackSet?.onLobby?.(lobbyState()); }
function send(message) {
  if (!channel || channel.readyState !== 'open') return false;
  try { channel.send(JSON.stringify(message)); return true; }
  catch (error) { console.warn('P2P send failed:', error); return false; }
}
function notifyView(snapshot, effects = []) { callbackSet?.onView?.(snapshot, effects); }
function sendLobby() {
  emitLobby();
  if (host) send({ type: 'lobby', state: lobbyState() });
}
function viewPair() {
  if (!engine) return null;
  return {
    attacker: engine.snapshotFor('attacker'),
    defender: engine.snapshotFor('defender'),
  };
}
function publishViews(before = null, command = null, params = {}, actorRole = '', result = { ok: true }) {
  if (!host || !engine) return;
  const after = viewPair();
  for (const side of ['attacker', 'defender']) {
    const effects = before
      ? engine.effects(before[side], after[side], side, command,
        { ...params, role: actorRole }, result)
      : [];
    if (side === 'attacker') {
      if (role === side) notifyView(after[side], effects);
      else send({ type: 'view', side, snapshot: after[side], effects });
    } else if (role === side) notifyView(after[side], effects);
    else send({ type: 'view', side, snapshot: after[side], effects });
  }
}
function maybeStart() {
  if (!host || started || !ready.attacker || !ready.defender) return;
  engine = new HVTGame(gameMap, 43, 20);
  started = true;
  sendLobby();
  publishViews();
}
async function runCommand(actorRole, command, params = {}, requestId = null) {
  if (!host || !engine || !started) {
    const result = { ok: false, msg: '房间未开始或房主尚未初始化游戏。' };
    if (requestId) send({ type: 'result', id: requestId, result });
    return result;
  }
  const before = viewPair();
  const result = engine.process(actorRole, command, params || {});
  publishViews(before, command, params || {}, actorRole, result);
  if (requestId) send({ type: 'result', id: requestId, result });
  return result;
}
function handleMessage(message) {
  if (!message || typeof message !== 'object') return;
  if (message.type === 'hello') {
    if (message.role !== (host ? 'defender' : 'attacker')) return;
    peerName = cleanName(message.nickname);
    if (!host && message.room) room = String(message.room).slice(0, 24);
    sendLobby();
    if (host) {
      send({ type: 'hello', role: 'attacker', nickname: myName, room });
      if (started) publishViews();
    }
    return;
  }
  if (message.type === 'lobby' && !host && message.state) {
    const state = message.state;
    if (state.room) room = String(state.room).slice(0, 24);
    started = !!state.started;
    ready = {
      attacker: !!state.players?.attacker?.ready,
      defender: !!state.players?.defender?.ready,
    };
    peerName = cleanName(state.players?.attacker?.nickname || peerName);
    emitLobby();
    return;
  }
  if (message.type === 'ready' && host && message.role === 'defender') {
    ready.defender = !!message.value;
    sendLobby();
    maybeStart();
    return;
  }
  if (message.type === 'command' && host && message.role === 'defender') {
    const id = String(message.id || '');
    const createdAt = Number(message.createdAt);
    if (!id) return;
    const expired = () => !Number.isFinite(createdAt) || createdAt <= 0 || Date.now() - createdAt > COMMAND_TTL_MS;
    if (expired()) {
      send({ type: 'result', id, result: { ok: false, msg: '指令已过期，未执行。请确认连接正常后重新操作。' } });
      return;
    }
    processing = processing.then(() => {
      if (expired()) {
        send({ type: 'result', id, result: { ok: false, msg: '指令在等待执行期间已过期，未执行。请重新操作。' } });
        return;
      }
      return runCommand('defender', message.command, message.params || {}, id);
    }).catch(error => {
      console.error('P2P command failed:', error);
      send({ type: 'result', id, result: { ok: false, msg: '房主执行指令失败，请检查控制台。' } });
    });
    return;
  }
  if (message.type === 'result' && !host) {
    const request = pendingRequests.get(String(message.id));
    if (request) {
      pendingRequests.delete(String(message.id));
      request.resolve(message.result || { ok: false, msg: '房主返回了空结果。' });
    }
    return;
  }
  if (message.type === 'view' && !host && message.side === 'defender' && message.snapshot) {
    notifyView(message.snapshot, Array.isArray(message.effects) ? message.effects : []);
  }
}
function setDataChannel(ch) {
  channel = ch;
  ch.onopen = () => {
    if (ch !== channel) return;
    updateConnectionState();
    send({ type: 'hello', role, nickname: myName, room });
    if (host) sendLobby();
  };
  ch.onclose = () => { if (ch === channel) updateConnectionState(); };
  ch.onerror = error => {
    console.warn('P2P DataChannel error:', error);
    if (ch === channel) updateConnectionState();
  };
  ch.onmessage = event => {
    if (ch !== channel) return;
    try { handleMessage(JSON.parse(event.data)); }
    catch (error) { console.warn('Ignoring invalid P2P message:', error); }
  };
}
function setPeerConnection(next) {
  pc = next;
  next.onconnectionstatechange = () => updateConnectionState(next);
  next.oniceconnectionstatechange = () => updateConnectionState(next);
  updateConnectionState(next);
}
function waitForIceGathering(connection) {
  if (connection.iceGatheringState === 'complete') return Promise.resolve();
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      connection.removeEventListener('icegatheringstatechange', check);
      reject(Error('收集网络连接信息超时。请刷新后重试，或改用不同网络。'));
    }, ICE_TIMEOUT_MS);
    const check = () => {
      if (connection.iceGatheringState !== 'complete') return;
      clearTimeout(timeout);
      connection.removeEventListener('icegatheringstatechange', check);
      resolve();
    };
    connection.addEventListener('icegatheringstatechange', check);
  });
}
function resetConnection() {
  generation++; clearTimeout(pollTimer); pollTimer = null; roomAuth = null; mode = 'manual'; connectionPath = 'unknown';
  for (const request of pendingRequests.values()) request.reject(Error('连接已关闭。'));
  pendingRequests.clear();
  const oldChannel = channel;
  const oldConnection = pc;
  pc = null; channel = null; engine = null; started = false;
  ready = { attacker: false, defender: false };
  offerText = ''; answerText = ''; incomingOffer = '';
  peerName = ''; connected = false; connectionStatus = 'idle';
  answerApplied = false; acceptingAnswer = null;
  callbackSet = null; processing = Promise.resolve();
  try { oldChannel?.close(); } catch {}
  try { oldConnection?.close(); } catch {}
}

async function start() {
  if (!('RTCPeerConnection' in window)) throw Error('此浏览器不支持 WebRTC，请使用较新的 Chrome、Edge、Firefox 或 Safari。');
  gameMap = await (await fetch(new URL('./seed43-map.json', import.meta.url))).json();
  return true;
}
async function createAutoRoom(name) {
  if (!OnlineSignal.enabled()) throw Error('自动房间尚未配置 CloudBase 环境。');
  resetConnection();
  mode = 'auto'; role = 'attacker'; host = true; myName = cleanName(name);
  const sequence = generation;
  let record;
  try {
    record = await OnlineSignal.call('open', { name: myName });
    if (sequence !== generation) throw Error('房间创建已取消。');
    room = record.code; roomAuth = { code: record.code, token: record.token };
    const connection = new RTCPeerConnection(record.ice);
    setPeerConnection(connection);
    setDataChannel(connection.createDataChannel('hvt-game', { ordered: true }));
    await connection.setLocalDescription(await connection.createOffer());
    await waitForIceGathering(connection);
    if (sequence !== generation) throw Error('房间创建已取消。');
    offerText = JSON.stringify(connection.localDescription);
    await OnlineSignal.call('offer', { code: room, token: record.token, description: connection.localDescription });
    if (sequence !== generation) throw Error('房间创建已取消。');
    updateConnectionState(connection);
    schedulePoll(sequence);
    return lobbyState();
  } catch (error) {
    if (record?.token) void OnlineSignal.call('leave', { code: record.code, token: record.token }).catch(() => {});
    resetConnection(); throw error;
  }
}
async function joinAutoRoom(code, side, name) {
  if (side !== 'defender') throw Error('房主为攻击方，加入者为防守方。');
  resetConnection();
  mode = 'auto'; role = 'defender'; host = false; myName = cleanName(name);
  const sequence = generation;
  let record;
  try {
    record = await OnlineSignal.call('join', { code: String(code).trim().toUpperCase(), name: myName });
    if (sequence !== generation) throw Error('加入房间已取消。');
    room = record.code; roomAuth = { code: record.code, token: record.token };
    const connection = new RTCPeerConnection(record.ice);
    setPeerConnection(connection);
    connection.ondatachannel = event => setDataChannel(event.channel);
    incomingOffer = JSON.stringify(record.offer);
    await connection.setRemoteDescription(record.offer);
    await connection.setLocalDescription(await connection.createAnswer());
    await waitForIceGathering(connection);
    if (sequence !== generation) throw Error('加入房间已取消。');
    answerText = JSON.stringify(connection.localDescription);
    await OnlineSignal.call('answer', { code: room, token: record.token, description: connection.localDescription });
    if (sequence !== generation) throw Error('加入房间已取消。');
    updateConnectionState(connection);
    schedulePoll(sequence);
    return lobbyState();
  } catch (error) {
    if (record?.token) void OnlineSignal.call('leave', { code: record.code, token: record.token }).catch(() => {});
    resetConnection(); throw error;
  }
}
function isAutoEnabled() { return OnlineSignal.enabled(); }
async function listRooms() {
  if (!OnlineSignal.enabled()) return [];
  const result = await OnlineSignal.call('list');
  return Array.isArray(result.rooms) ? result.rooms : [];
}
async function createRoom(name) {
  resetConnection();
  role = 'attacker'; host = true; myName = cleanName(name); room = `P2P-${randomCode()}`;
  const connection = new RTCPeerConnection(RTC_CONFIG);
  setPeerConnection(connection);
  setDataChannel(connection.createDataChannel('hvt-game', { ordered: true }));
  const offer = await connection.createOffer();
  await connection.setLocalDescription(offer);
  await waitForIceGathering(connection);
  offerText = JSON.stringify(connection.localDescription);
  updateConnectionState(connection);
  ready.attacker = false;
  return lobbyState();
}
async function joinRoom(offer, side, name) {
  if (side !== 'defender') throw Error('GitHub-only 联机模式中，房主固定为攻击方，加入者为防守方。');
  resetConnection();
  role = 'defender'; host = false; myName = cleanName(name); room = 'P2P-CONNECTING';
  incomingOffer = String(offer || '').trim();
  const description = parseDescription(incomingOffer, 'offer');
  const connection = new RTCPeerConnection(RTC_CONFIG);
  setPeerConnection(connection);
  connection.ondatachannel = event => setDataChannel(event.channel);
  await connection.setRemoteDescription(description);
  const answer = await connection.createAnswer();
  await connection.setLocalDescription(answer);
  await waitForIceGathering(connection);
  answerText = JSON.stringify(connection.localDescription);
  updateConnectionState(connection);
  return lobbyState();
}
async function acceptAnswer(answer) {
  if (!host || !pc) throw Error('当前页面不是等待答复的房主页面。');
  if (answerApplied) return false; // Idempotent: never apply a second Answer to stable state.
  if (acceptingAnswer) return acceptingAnswer;
  if (pc.signalingState !== 'have-local-offer') {
    throw Error('当前连接不在等待答复状态。请双方返回首页，重新生成一套邀请与答复。');
  }
  const description = parseDescription(answer, 'answer');
  const connection = pc;
  acceptingAnswer = (async () => {
    await connection.setRemoteDescription(description);
    if (connection !== pc) throw Error('连接已重置，请重新创建邀请。');
    answerApplied = true;
    updateConnectionState(connection);
    return true;
  })();
  try { return await acceptingAnswer; }
  finally { acceptingAnswer = null; }
}
function getSignalInfo() { return { offer: offerText, answer: answerText, role, room }; }
function getConnectionInfo() { return { status: connectionStatus, connected, answerApplied, mode, path: connectionPath }; }
async function resume() { throw Error('WebRTC 直连不能在刷新页面后自动恢复，请重新创建邀请并建立连接。'); }
function getLobby() { return lobbyState(); }
async function toggleReady(next) {
  if (!connected || !channel || channel.readyState !== 'open') throw Error('请先完成邀请/答复交换，等待连接状态显示“已连接”。');
  if (started) throw Error('对局已经开始。');
  ready[role] = !!next;
  if (host) {
    sendLobby();
    maybeStart();
  } else {
    send({ type: 'ready', role: 'defender', value: !!next });
    emitLobby();
  }
  return lobbyState();
}
async function leave() {
  const auth = roomAuth;
  if (auth) await OnlineSignal.call('leave', auth).catch(error => console.warn('Failed to close room:', error));
  resetConnection(); room = ''; role = ''; host = false; myName = 'Player';
}
function listen(onLobby, onView, onOnline, onConnectionStatus) {
  callbackSet = { onLobby, onView, onOnline, onConnectionStatus };
  emitLobby();
  callbackSet?.onOnline?.(connected && channel?.readyState === 'open');
  callbackSet?.onConnectionStatus?.(connectionStatus);
  if (channel?.readyState === 'open') {
    send({ type: 'hello', role, nickname: myName, room });
    if (host) sendLobby();
    if (host && started) publishViews();
  }
  return () => { if (callbackSet?.onLobby === onLobby) callbackSet = null; };
}
async function sendCommand(command, params = {}) {
  if (!started) throw Error('双方尚未准备。');
  if (!connected || !channel || channel.readyState !== 'open') throw Error('连接已断开，请重新建立邀请连接。');
  if (host) {
    const id = `host-${++requestSerial}`;
    const result = await runCommand('attacker', command, params, null);
    return result;
  }
  const id = `guest-${Date.now()}-${++requestSerial}`;
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      pendingRequests.delete(id);
      reject(Error('房主未在 18 秒内响应。请确认房主页面仍然打开且连接正常。'));
    }, 18000);
    pendingRequests.set(id, {
      resolve: value => { clearTimeout(timer); resolve(value); },
      reject: error => { clearTimeout(timer); reject(error); },
    });
    if (!send({ type: 'command', id, role: 'defender', command, params, createdAt: Date.now() })) {
      clearTimeout(timer); pendingRequests.delete(id); reject(Error('无法发送指令，连接可能已断开。'));
    }
  });
}

export const HVTBackend = { start, createRoom, joinRoom, createAutoRoom, joinAutoRoom, listRooms, isAutoEnabled, resume, getLobby, toggleReady, leave, listen, sendCommand, acceptAnswer, getSignalInfo, getConnectionInfo };
